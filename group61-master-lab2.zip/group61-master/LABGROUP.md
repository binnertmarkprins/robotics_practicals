This is the private repository for Group 61.
Course: ME41025 - Robotics Practicals 2017-2018, TU Delft