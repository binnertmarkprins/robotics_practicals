# Game group 61

In this short guide we will explain how to build and run our game.

## Step 1

Clone the git-repo in your shell:

```bash
git clone https://gitlab.me41025.3me.tudelft.nl/students-1920/lab2/group61 ~/game61
```

Or download the zip-file.

## Step 2

Run the following shell script:

```bash
cd ~/game61
cmake .
make all
./game
```

## Enjoy!
And respect the rules of the game 

## License
Binnert Prins, Tom Kerssemakers