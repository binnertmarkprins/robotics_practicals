# Lab group info
This is the private repository for **Group 61**.

Course: ME41025 - Robotics Practicals 2019-2020, TU Delft

Binnert Prins and Tom Kersenmakers


